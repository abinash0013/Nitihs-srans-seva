<?php 
    include 'header.php'
?>

<?php 
    include 'sidebar.php'
?>

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix p-3">
                <h4 class="page-title pull-left">Dashboard</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="index.php">Home</a></li>
                    <li><span>Dashboard</span></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- page title area end -->

<!-- main content area start -->
<div class="main-content">
    <div class="main-content-inner">
        <!-- sales report area start -->
        <div class="sales-report-area mt-5 mb-5">
            <div class="row">
                <div class="col-md-4">
                    <div class="single-report mb-xs-30">
                        <div class="s-report-inner pr--20 pt--30 mb-3">
                            <div class="icon"><i class="fa fa-user"></i></div>
                            <div class="s-report-title d-flex justify-content-between">
                                <h3 class="text-center">Welcome to Delhi Golden Lottery</h3>
                            </div>
                        </div>
                        <canvas id="coin_sales1" height="100"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <!-- sales report area end -->
    </div>
    <!-- main content area end -->
</div>
<!-- page container area end -->

<?php
    include 'footer.php';
?>